"use client"

import { createMachine, assign } from "xstate"

interface UIContext {
  selectedCards: string[]
  currentAction: string | null
  error: string | null
}

type UIEvent =
  | { type: "SELECT_CARD"; cardId: string }
  | { type: "DESELECT_CARD"; cardId: string }
  | { type: "PLAY" }
  | { type: "DRAW" }
  | { type: "CHECK" }
  | { type: "FOLD" }
  | { type: "JOIN_GAME"; gameId: string }
  | { type: "RESET" }
  | { type: "ERROR"; message: string }

export const uiMachine = createMachine<UIContext, UIEvent>({
  id: "ui",
  initial: "idle",
  context: {
    selectedCards: [],
    currentAction: null,
    error: null,
  },
  states: {
    idle: {
      on: {
        SELECT_CARD: {
          actions: assign({
            selectedCards: (context, event) => {
              const { cardId } = event
              return context.selectedCards.includes(cardId)
                ? context.selectedCards.filter((id) => id !== cardId)
                : [...context.selectedCards, cardId]
            },
          }),
        },
        PLAY: {
          target: "playing",
          actions: assign({ currentAction: "play" }),
        },
        DRAW: {
          target: "drawing",
          actions: assign({ currentAction: "draw" }),
        },
        CHECK: {
          target: "checking",
          actions: assign({ currentAction: "check" }),
        },
        FOLD: {
          target: "folding",
          actions: assign({ currentAction: "fold" }),
        },
        JOIN_GAME: {
          target: "connecting",
          actions: assign({ currentAction: "join" }),
        },
      },
    },
    connecting: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            currentAction: null,
            error: null,
          }),
        },
        ERROR: {
          target: "error",
          actions: assign({
            error: (_, event) => event.message,
          }),
        },
      },
    },
    playing: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            selectedCards: [],
            currentAction: null,
            error: null,
          }),
        },
      },
    },
    drawing: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            currentAction: null,
            error: null,
          }),
        },
      },
    },
    checking: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            selectedCards: [],
            currentAction: null,
            error: null,
          }),
        },
      },
    },
    folding: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            selectedCards: [],
            currentAction: null,
            error: null,
          }),
        },
      },
    },
    error: {
      on: {
        RESET: {
          target: "idle",
          actions: assign({
            selectedCards: [],
            currentAction: null,
            error: null,
          }),
        },
      },
    },
  },
})

// Hook for using the UI machine
import { useMachine } from "@xstate/react"

export function useUIMachine() {
  return useMachine(uiMachine)
}
