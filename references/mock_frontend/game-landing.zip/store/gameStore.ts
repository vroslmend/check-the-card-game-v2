"use client"

import { create } from "zustand"
import { io, type Socket } from "socket.io-client"

interface GameState {
  id: string
  phase: string
  currentPlayer: string
  players: any[]
  localPlayer: any
  deck: { count: number }
  discardPile: any[]
  log: any[]
  chat: any[]
}

interface GameStore {
  socket: Socket | null
  isConnected: boolean
  gameState: GameState | null

  // Actions
  connect: (gameId: string) => void
  disconnect: () => void
  emit: (event: string, data?: any) => void
  setGameState: (state: GameState) => void
  addLogEntry: (entry: any) => void
  addChatMessage: (message: any) => void
}

export const useGameStore = create<GameStore>((set, get) => ({
  socket: null,
  isConnected: false,
  gameState: null,

  connect: (gameId: string) => {
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:3001")

    socket.on("connect", () => {
      set({ isConnected: true })
      socket.emit("joinGame", { gameId })
    })

    socket.on("disconnect", () => {
      set({ isConnected: false })
    })

    socket.on("gameStateUpdate", (state: GameState) => {
      get().setGameState(state)
    })

    socket.on("gameLog", (entry: any) => {
      get().addLogEntry(entry)
    })

    socket.on("chatMessage", (message: any) => {
      get().addChatMessage(message)
    })

    set({ socket })
  },

  disconnect: () => {
    const { socket } = get()
    if (socket) {
      socket.disconnect()
      set({ socket: null, isConnected: false, gameState: null })
    }
  },

  emit: (event: string, data?: any) => {
    const { socket } = get()
    if (socket && socket.connected) {
      socket.emit(event, data)
    }
  },

  setGameState: (state: GameState) => {
    set({ gameState: state })
  },

  addLogEntry: (entry: any) => {
    set((state) => ({
      gameState: state.gameState
        ? {
            ...state.gameState,
            log: [...state.gameState.log, entry],
          }
        : null,
    }))
  },

  addChatMessage: (message: any) => {
    set((state) => ({
      gameState: state.gameState
        ? {
            ...state.gameState,
            chat: [...state.gameState.chat, message],
          }
        : null,
    }))
  },
}))
